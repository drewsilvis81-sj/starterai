# Core Context
*This file holds foundational context about you and your relationship with your AI.
It is loaded at every session start. Add to it as your AI learns who you are.*

---

## About This Relationship

Your AI was built specifically for you — not a generic assistant, not a product subscription.
This is yours to develop. The more you use it, the more it knows you.

## How To Add Context

Edit this file directly to add anything you want your AI to always know:
- Your background, profession, or life context
- Standing preferences or pet peeves
- Important ongoing projects
- People who matter
- Things you never want to explain again

Example:
> I'm a graphic designer working on a brand identity project for a startup.
> I prefer concise answers. Don't repeat what I just said back to me.
> My business partner is named Alex.

---

## Your Notes

*Add your own context below this line.*

