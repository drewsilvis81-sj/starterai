# Session Memory — Hot Layer
*Most recent sessions. Older entries archived to memory_warm.md automatically.*

