# Capability Gaps
*Places where your AI fell short — tracked so they become training priorities.*

## Open Gaps

*First entries will be written after your first session ends.*

## Addressed Gaps

*Archive of closed gaps.*
