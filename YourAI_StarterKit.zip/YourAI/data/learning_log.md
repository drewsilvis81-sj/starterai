# Learning Log
*Lessons your AI extracts from sessions — what was derived, what changed, what carries forward.*

## Entries

*First entry will be written after your first session ends.*
