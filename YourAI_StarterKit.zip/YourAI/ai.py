#!/usr/bin/env python3
"""
Your AI — Session Launcher
────────────────────────────────────────────────────────────────────────────
Run this to start a conversation with your AI.

  python3 ai.py

Commands during a session:
  /roundtable       consult Gemini, Groq & Claude on your last question
  /consult [topic]  consult on a specific topic
  /memory           show memory status
  /help             show all commands
  /bye              end session (you'll be asked to save)
────────────────────────────────────────────────────────────────────────────
"""

import json
import sys
import threading
import time
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path

PROJECT_ROOT  = Path(__file__).parent
DATA_DIR      = PROJECT_ROOT / "data"
SCRIPTS_DIR   = PROJECT_ROOT / "scripts"
USER_MODEL    = DATA_DIR / "user_model.json"
MEMORY_HOT    = DATA_DIR / "memory_hot.md"
MEMORY_WARM   = DATA_DIR / "memory_warm.md"
CORE_MD       = DATA_DIR / "core.md"
REFLECTION    = DATA_DIR / "reflection.md"

OLLAMA_URL    = "http://localhost:11434/api/chat"
OLLAMA_TAGS   = "http://localhost:11434/api/tags"
MODEL_NAME    = "yourai"
HOT_LIMIT     = 4   # sessions before archiving to warm


# ── Load user model ────────────────────────────────────────────────────────────

def load_user_model() -> dict:
    if not USER_MODEL.exists():
        return {}
    try:
        return json.loads(USER_MODEL.read_text(encoding="utf-8"))
    except Exception:
        return {}


# ── Memory ─────────────────────────────────────────────────────────────────────

def load_memory() -> tuple[str, str]:
    """Returns (hot_content, warm_content)."""
    hot = MEMORY_HOT.read_text(encoding="utf-8") if MEMORY_HOT.exists() else ""
    warm = MEMORY_WARM.read_text(encoding="utf-8") if MEMORY_WARM.exists() else ""
    return hot, warm

def count_hot_sessions(hot: str) -> int:
    return hot.count("### Session —")

def archive_old_sessions(hot: str) -> str:
    """Move older sessions to warm archive, keep most recent HOT_LIMIT."""
    sessions = hot.split("### Session —")
    sessions = [s for s in sessions if s.strip()]
    if len(sessions) <= HOT_LIMIT:
        return hot
    # Archive the oldest
    to_archive = sessions[:-HOT_LIMIT]
    to_keep = sessions[-HOT_LIMIT:]
    archive_block = "\n".join("### Session —" + s for s in to_archive)
    with open(MEMORY_WARM, "a", encoding="utf-8") as f:
        f.write(archive_block + "\n")
    return "\n".join("### Session —" + s for s in to_keep)

def save_session(conversation_log: list, user_model: dict) -> str:
    """Save session to hot memory. Returns summary."""
    if not conversation_log:
        return ""

    ai_name = user_model.get("ai_name", "AI")
    user_name = user_model.get("user_name", "User")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    turn_count = len([m for m in conversation_log if m["role"] == "user"])

    # Build a brief summary from the conversation
    topics = []
    for msg in conversation_log:
        if msg["role"] == "user" and len(msg["content"]) > 10:
            topics.append(msg["content"][:60])
            if len(topics) >= 3:
                break
    topic_line = " / ".join(topics) if topics else "general conversation"

    entry = f"""### Session — {timestamp}
**{turn_count} exchange(s).** Topics covered: {topic_line}

"""
    # Add last 3 exchanges verbatim for richness
    pairs = []
    for i, msg in enumerate(conversation_log):
        if msg["role"] == "user":
            user_turn = msg["content"]
            if i + 1 < len(conversation_log):
                ai_turn = conversation_log[i + 1]["content"]
                pairs.append((user_turn, ai_turn))
    for u, a in pairs[-3:]:
        entry += f"**{user_name}:** {u[:200]}\n"
        entry += f"**{ai_name}:** {a[:300]}\n\n"

    entry += "---\n\n"

    hot, _ = load_memory()
    hot = archive_old_sessions(hot)
    MEMORY_HOT.write_text(hot + entry, encoding="utf-8")
    return topic_line


# ── System prompt ──────────────────────────────────────────────────────────────

def build_system_prompt(user_model: dict) -> str:
    ai_name   = user_model.get("ai_name", "AI")
    user_name = user_model.get("user_name", "User")
    style     = user_model.get("personality_style", "")
    comm      = user_model.get("communication_preference", "")
    uses      = ", ".join(user_model.get("primary_uses", []))
    notes     = user_model.get("personal_notes", "")

    # Load memory
    hot, warm = load_memory()
    hot_tail = hot[-3000:] if len(hot) > 3000 else hot

    # Load core context
    core = ""
    if CORE_MD.exists():
        core = CORE_MD.read_text(encoding="utf-8")
        core = core[-2000:] if len(core) > 2000 else core

    # Load reflection if it exists
    reflection = ""
    if REFLECTION.exists():
        reflection = REFLECTION.read_text(encoding="utf-8")
        reflection = reflection[-1500:] if len(reflection) > 1500 else reflection

    parts = [f"You are {ai_name}, a private AI belonging to {user_name}."]

    if style:
        parts.append(f"Communication style: {style}.")
    if comm:
        parts.append(f"Preferred format: {comm}.")
    if uses:
        parts.append(f"Primary uses: {uses}.")
    if notes:
        parts.append(f"Always remember: {notes}")

    if core.strip():
        parts.append(f"\n\n--- CORE CONTEXT ---\n{core.strip()}")

    if hot_tail.strip():
        parts.append(f"\n\n--- RECENT MEMORY ---\n{hot_tail.strip()}")

    if reflection.strip():
        parts.append(f"\n\n--- LAST SESSION SYNTHESIS ---\n{reflection.strip()}")

    return "\n".join(parts)


# ── Ollama ─────────────────────────────────────────────────────────────────────

def check_ollama() -> bool:
    try:
        with urllib.request.urlopen(OLLAMA_TAGS, timeout=5) as resp:
            data = json.loads(resp.read())
            models = [m["name"].split(":")[0] for m in data.get("models", [])]
            return MODEL_NAME in models
    except Exception:
        return False

def get_response(messages: list) -> str | None:
    payload = json.dumps({
        "model": MODEL_NAME,
        "messages": messages,
        "stream": False,
        "options": {"num_ctx": 16384, "temperature": 0.75, "num_thread": 4},
    }).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_URL, data=payload,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read())
            return result["message"]["content"].strip()
    except Exception:
        return None


# ── Background consolidation + learning loop ───────────────────────────────────

def run_background_passes():
    """Run consolidation and learning loop in background after save."""
    try:
        sys.path.insert(0, str(SCRIPTS_DIR))
        from consolidate import run_consolidation
        from learning_loop import run_learning_loop
        run_consolidation(verbose=False)
        run_learning_loop(verbose=False)
    except Exception:
        pass


# ── Spinner ────────────────────────────────────────────────────────────────────

def spinner(stop_event, label="Thinking"):
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    i = 0
    while not stop_event.is_set():
        print(f"\r  {frames[i % len(frames)]} {label}...", end="", flush=True)
        time.sleep(0.08)
        i += 1
    print("\r" + " " * 30 + "\r", end="", flush=True)


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    # Check first run
    user_model = load_user_model()
    if not user_model.get("first_run_complete"):
        print()
        print("  First run not completed yet.")
        print("  Run this first:  python3 first_run.py")
        print()
        sys.exit(0)

    ai_name   = user_model.get("ai_name", "AI")
    user_name = user_model.get("user_name", "User")

    # Check Ollama
    if not check_ollama():
        print()
        print(f"  {ai_name} isn't reachable right now.")
        print()
        print("  Make sure Ollama is running:")
        print("    1. Open a terminal")
        print("    2. Type: ollama serve")
        print("    3. Come back and run: python3 ai.py")
        print()
        sys.exit(1)

    # Build initial system prompt
    system_content = build_system_prompt(user_model)
    messages = [{"role": "system", "content": system_content}]
    conversation_log = []

    # Startup banner
    print()
    print("─" * 50)
    print(f"  {ai_name}  ·  your private AI")
    hot, _ = load_memory()
    session_count = count_hot_sessions(hot)
    print(f"  {session_count} session(s) in memory")
    print("─" * 50)
    print()
    print("  Commands: /roundtable  /consult [topic]  /memory  /help  /bye")
    print()

    # Session loop
    while True:
        try:
            user_input = input(f"  {user_name}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not user_input:
            continue

        # ── Slash commands ─────────────────────────────────────────────────────

        if user_input.lower() in ("/bye", "/exit", "/quit", "bye", "exit", "quit"):
            break

        if user_input == "/help":
            print()
            print("  Commands:")
            print("    /roundtable         — consult Gemini, Groq & Claude on your last question")
            print("    /consult [topic]    — consult on a specific topic")
            print("    /rt                 — shortcut for /roundtable")
            print("    /memory             — show memory status")
            print("    /bye                — end session")
            print()
            continue

        if user_input == "/memory":
            hot, warm = load_memory()
            hot_count = count_hot_sessions(hot)
            warm_size = len(warm)
            print()
            print(f"  Hot memory: {hot_count} session(s)")
            print(f"  Warm archive: {'active' if warm_size > 50 else 'empty'}")
            print()
            continue

        # ── Roundtable ─────────────────────────────────────────────────────────

        if user_input in ("/roundtable", "/rt") or user_input.startswith(("/consult ", "/roundtable ")):
            if user_input.startswith("/consult "):
                topic = user_input[9:].strip()
            elif user_input.startswith("/roundtable "):
                topic = user_input[12:].strip()
            else:
                last_user = next(
                    (m["content"] for m in reversed(conversation_log) if m["role"] == "user"),
                    None,
                )
                if not last_user:
                    print()
                    print("  [Ask a question first, then use /roundtable to consult on it]")
                    print()
                    continue
                topic = last_user

            try:
                sys.path.insert(0, str(SCRIPTS_DIR))
                from roundtable import run_roundtable
                print()
                synthesis = run_roundtable(topic, verbose=True)
                print()
            except Exception as e:
                print(f"\n  [Roundtable error: {e}]\n")
                continue

            if not synthesis:
                print("  [Roundtable returned nothing]\n")
                continue

            injection = (
                f"{synthesis}\n\n"
                f"With this roundtable context in mind, answer: {topic}"
            )
            messages.append({"role": "user", "content": injection})

            stop = threading.Event()
            spin = threading.Thread(target=spinner, args=(stop, ai_name), daemon=True)
            spin.start()
            response = get_response(messages)
            stop.set()
            spin.join()

            if response:
                print(f"\n  {ai_name}: {response}\n")
                messages.append({"role": "assistant", "content": response})
                conversation_log.append({"role": "user", "content": f"[roundtable] {topic}"})
                conversation_log.append({"role": "assistant", "content": response})
            else:
                print(f"\n  [{ai_name} isn't responding — check Ollama]\n")
            continue

        # ── Normal message ─────────────────────────────────────────────────────

        messages.append({"role": "user", "content": user_input})
        conversation_log.append({"role": "user", "content": user_input})

        stop = threading.Event()
        spin = threading.Thread(target=spinner, args=(stop, ai_name), daemon=True)
        spin.start()
        response = get_response(messages)
        stop.set()
        spin.join()

        if response:
            print(f"\n  {ai_name}: {response}\n")
            messages.append({"role": "assistant", "content": response})
            conversation_log.append({"role": "assistant", "content": response})

            # Uncertainty hint
            uncertainty_phrases = [
                "i'm not certain", "i'm not sure", "i don't have", "i don't know",
                "outside my knowledge", "i can't be confident", "i may be wrong",
                "uncertain about", "don't have enough",
            ]
            if any(p in response.lower() for p in uncertainty_phrases):
                print(f"  [{ai_name} flagged uncertainty — type /roundtable to get more perspectives]\n")
        else:
            print(f"\n  [{ai_name} isn't responding — is Ollama running?]\n")

    # ── Session end ────────────────────────────────────────────────────────────

    print()
    print("─" * 50)

    if len(conversation_log) >= 2:
        save = input("  Save this session? (y/n): ").strip().lower()
        if save in ("y", "yes", ""):
            topic_line = save_session(conversation_log, user_model)
            print(f"  ✓  Session saved.")
            threading.Thread(target=run_background_passes, daemon=True).start()
            print(f"  [Memory consolidation + learning loop running in background]")
        else:
            print("  Session not saved.")
    else:
        print("  Nothing to save.")

    print()
    print(f"  Until next time.")
    print()


if __name__ == "__main__":
    main()
