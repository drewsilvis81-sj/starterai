# User Guide — Day to Day

---

## Starting a Session

```
python3 ai.py
```

Your AI loads your memory, your profile, and the synthesis from your last session.
By the time you send your first message, it already knows where you left off.

---

## Ending a Session

Type `/bye`. You'll be asked:
```
Save this session? (y/n):
```
Say yes. Saving is how your AI remembers. A session that isn't saved doesn't exist
in memory — your AI starts the next conversation without it.

After saving, your AI runs two background processes:
- **Consolidation** — synthesizes patterns from recent sessions, writes a reflection that primes the next conversation
- **Learning loop** — extracts lessons, detects capability gaps, generates training candidates

You won't see these happen. They finish quietly and make the next session better.

---

## The Roundtable

When your AI isn't sure about something, or when you want more perspectives:

**`/roundtable`** — consults on your last question
**`/consult quantum computing`** — consults on a specific topic

Three external AIs (Gemini, Groq, Claude) each respond simultaneously.
Your AI synthesizes their input and answers you with that context added.

If your AI hedges — "I'm not certain", "outside my knowledge" — it will suggest
the roundtable automatically.

Requires API keys in `.env`. See `.env.example`.

---

## Adding Context Your AI Always Remembers

Edit `data/core.md` directly. Add anything you want it to always carry:

```
I'm a UX designer at a startup. My co-founder is named Sam.
I prefer direct feedback. Don't soften criticism.
Current project: redesigning our onboarding flow.
```

This loads at every session start.

---

## Reviewing Training Candidates

After several sessions, your AI will start generating training candidates —
interactions it thinks are worth encoding into its behavior permanently.

Review them with:
```
python3 scripts/merge_training.py
```

You approve, reject, or edit each one. Approved examples become permanent
behavioral training once you run a fine-tune (advanced — see docs for that later).

---

## Checking What Your AI Has Learned

**`data/learning_log.md`** — lessons extracted from sessions

**`data/capability_gaps.md`** — where it fell short (your training priority list)

**`data/reflection.md`** — the synthesis from your last session end

These are plain text files. Read them. Edit them. They're yours.

---

## Developing Your AI Over Time

Your AI is a starting point, not a finished product. Things you can do:

- **Add to `data/core.md`** — give it more context about your life and work
- **Review learning_log.md** — see what it's picking up about you
- **Close gaps in capability_gaps.md** — those become your fine-tuning priorities
- **Fine-tune** — after enough training candidates accumulate, you can bake approved behavior into the model weights permanently (advanced guide coming)

The more you use it, the more it knows you. That's the point.
