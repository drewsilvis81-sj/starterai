#!/usr/bin/env python3
"""
First Run — Personalization Session
────────────────────────────────────────────────────────────────────────────
This runs once, the very first time you start your AI.
It introduces you to each other, asks you a few questions, and builds
the foundation your AI will use for every conversation going forward.

After this completes, use ai.py to start sessions.
────────────────────────────────────────────────────────────────────────────
"""

import json
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent
USER_MODEL   = PROJECT_ROOT / "data" / "user_model.json"
MODELFILE    = PROJECT_ROOT / "Modelfile"
MEMORY_HOT   = PROJECT_ROOT / "data" / "memory_hot.md"
CORE_MD      = PROJECT_ROOT / "data" / "core.md"

OLLAMA_URL   = "http://localhost:11434/api/chat"
OLLAMA_TAGS  = "http://localhost:11434/api/tags"
MODEL_NAME   = "yourai"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _clear():
    print("\n" * 2)

def _pause(seconds=1.2):
    time.sleep(seconds)

def _slow_print(text, delay=0.018):
    """Print text character by character for a conversational feel."""
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()

def _ask(prompt, required=True):
    """Ask a question and return the answer. Re-prompts if required and empty."""
    while True:
        print()
        answer = input(f"  {prompt}\n  > ").strip()
        if answer or not required:
            return answer
        print("  (Please enter a response to continue)")

def _ask_choice(prompt, choices, default=None):
    """Present numbered choices and return the selected value."""
    print(f"\n  {prompt}")
    for i, choice in enumerate(choices, 1):
        marker = " (default)" if choice == default else ""
        print(f"    {i}. {choice}{marker}")
    print()
    while True:
        raw = input("  Enter a number, or type your own answer: ").strip()
        if not raw and default:
            return default
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        except ValueError:
            pass
        if raw:
            return raw
        print("  (Please choose a number or type your answer)")

def _check_ollama():
    """Check if Ollama is running and the model is installed."""
    try:
        with urllib.request.urlopen(OLLAMA_TAGS, timeout=5) as resp:
            data = json.loads(resp.read())
            models = [m["name"].split(":")[0] for m in data.get("models", [])]
            return MODEL_NAME in models, models
    except Exception:
        return None, []

def _call_ai(messages):
    """Send messages to the AI and return the response."""
    payload = json.dumps({
        "model": MODEL_NAME,
        "messages": messages,
        "stream": False,
        "options": {"num_ctx": 8192, "temperature": 0.75, "num_thread": 4},
    }).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_URL, data=payload,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read())["message"]["content"].strip()
    except Exception:
        return None

def _update_modelfile(ai_name, user_name):
    """Replace placeholders in Modelfile with actual names."""
    if not MODELFILE.exists():
        return
    content = MODELFILE.read_text(encoding="utf-8")
    content = content.replace("[AI_NAME]", ai_name)
    content = content.replace("[USER_NAME]", user_name)
    MODELFILE.write_text(content, encoding="utf-8")

def _rebuild_model(ai_name, user_name):
    """Rebuild the Ollama model with personalized Modelfile."""
    import subprocess
    _update_modelfile(ai_name, user_name)
    try:
        result = subprocess.run(
            ["ollama", "create", MODEL_NAME, "-f", str(MODELFILE)],
            capture_output=True, text=True, timeout=120
        )
        return result.returncode == 0
    except Exception:
        return False

def _save_user_model(data):
    USER_MODEL.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def _load_user_model():
    if not USER_MODEL.exists():
        return {}
    try:
        return json.loads(USER_MODEL.read_text(encoding="utf-8"))
    except Exception:
        return {}


# ── Personalization Flow ───────────────────────────────────────────────────────

def run_first_run():
    model = _load_user_model()

    # Already completed
    if model.get("first_run_complete"):
        print("\nPersonalization already complete. Run ai.py to start a session.")
        print(f"Your AI's name: {model.get('ai_name', '(unknown)')}")
        sys.exit(0)

    _clear()

    # ── Welcome ────────────────────────────────────────────────────────────────
    print("=" * 60)
    print()
    _slow_print("  Welcome.")
    _pause(0.8)
    print()
    _slow_print("  You've been given something a little unusual —")
    _slow_print("  a private AI that belongs only to you.")
    _pause(0.6)
    print()
    _slow_print("  Before your first real conversation, we need to do")
    _slow_print("  a few things together. It won't take long.")
    _pause(0.5)
    print()
    _slow_print("  This session will:")
    _pause(0.3)
    _slow_print("    — Give your AI a name")
    _pause(0.2)
    _slow_print("    — Let your AI know who you are")
    _pause(0.2)
    _slow_print("    — Set the tone for how you want to work together")
    _pause(0.2)
    _slow_print("    — Start your first real conversation")
    print()
    print("=" * 60)
    _pause(1.0)

    # ── Check Ollama ───────────────────────────────────────────────────────────
    print()
    print("  Checking setup...")
    installed, available_models = _check_ollama()

    if installed is None:
        print()
        print("  ✗  Ollama isn't running.")
        print()
        print("  To fix this:")
        print("    1. Open a new terminal window")
        print("    2. Type: ollama serve")
        print("    3. Come back here and run this script again")
        print()
        sys.exit(1)

    if not installed:
        print()
        print("  ✗  Your AI model isn't installed yet.")
        print()
        print("  Run install.sh first, then come back:")
        print("    bash install.sh")
        print()
        sys.exit(1)

    print("  ✓  Everything looks good.")
    _pause(0.8)

    # ── Step 1: User's name ────────────────────────────────────────────────────
    print()
    print("─" * 60)
    print()
    _slow_print("  Step 1 of 5 — Let's start with you.")
    print()

    user_name = _ask("What's your name?")
    print()
    _slow_print(f"  Nice to meet you, {user_name}.")
    _pause(0.6)

    # ── Step 2: AI's name ──────────────────────────────────────────────────────
    print()
    print("─" * 60)
    print()
    _slow_print("  Step 2 of 5 — Name your AI.")
    print()
    _slow_print("  This is the name your AI will carry through every conversation.")
    _slow_print("  It becomes part of how it identifies itself.")
    print()

    ai_name = _ask_choice(
        "What would you like to call your AI?",
        ["Atlas", "Ember", "Sage", "Lumen", "Cairn", "Haven"],
        default=None
    )
    print()
    _slow_print(f"  {ai_name}. That's a good name.")
    _pause(0.8)

    # ── Step 3: Personality style ──────────────────────────────────────────────
    print()
    print("─" * 60)
    print()
    _slow_print("  Step 3 of 5 — How should your AI communicate?")
    print()
    _slow_print("  Your AI will adapt to you over time, but it helps to start")
    _slow_print("  in the right direction.")
    print()

    style = _ask_choice(
        "Pick the style that fits best:",
        [
            "Direct and brief — get to the point, no padding",
            "Warm and thorough — full explanations, conversational tone",
            "Analytical — structured thinking, pros/cons, careful reasoning",
            "Balanced — adapts based on the topic",
        ],
        default="Balanced — adapts based on the topic"
    )

    comm_pref = _ask_choice(
        "How do you prefer to receive information?",
        [
            "Flowing prose — write in paragraphs",
            "Lists and structure — organize it clearly",
            "Mix — use whatever fits the content",
        ],
        default="Mix — use whatever fits the content"
    )

    # ── Step 4: Primary uses ───────────────────────────────────────────────────
    print()
    print("─" * 60)
    print()
    _slow_print("  Step 4 of 5 — What will you use your AI for?")
    print()
    _slow_print("  Check as many as apply. Type the numbers separated by commas.")
    print()

    use_options = [
        "Thinking partner / sounding board",
        "Writing and editing",
        "Research and learning",
        "Work and professional tasks",
        "Creative projects",
        "Personal organization and planning",
        "Technical / coding help",
        "Emotional support and reflection",
    ]

    for i, opt in enumerate(use_options, 1):
        print(f"    {i}. {opt}")

    print()
    raw_uses = input("  Enter numbers (e.g. 1,3,5) or describe in your own words: ").strip()
    primary_uses = []
    try:
        for part in raw_uses.split(","):
            idx = int(part.strip()) - 1
            if 0 <= idx < len(use_options):
                primary_uses.append(use_options[idx])
    except ValueError:
        if raw_uses:
            primary_uses = [raw_uses]

    if not primary_uses:
        primary_uses = ["General thinking partner"]

    # ── Step 5: Personal note ──────────────────────────────────────────────────
    print()
    print("─" * 60)
    print()
    _slow_print("  Step 5 of 5 — Anything important I should know right away?")
    print()
    _slow_print("  This is optional. But if there's something about your life,")
    _slow_print("  your work, or your situation that you'd want your AI to carry")
    _slow_print("  from day one — this is the place.")
    print()

    personal_note = _ask(
        "Tell your AI something it should always know about you. (Press Enter to skip)",
        required=False
    )

    # ── Save user model ────────────────────────────────────────────────────────
    user_model = {
        "user_name": user_name,
        "ai_name": ai_name,
        "personality_style": style,
        "communication_preference": comm_pref,
        "primary_uses": primary_uses,
        "personal_notes": personal_note,
        "first_run_complete": True,
        "created_at": datetime.now().strftime("%Y-%m-%d"),
    }
    _save_user_model(user_model)

    # Update core.md with user's personal note if provided
    if personal_note:
        core_content = CORE_MD.read_text(encoding="utf-8")
        core_content += f"\n{personal_note}\n"
        CORE_MD.write_text(core_content, encoding="utf-8")

    # ── Rebuild model with personalized Modelfile ──────────────────────────────
    print()
    print("─" * 60)
    print()
    _slow_print(f"  Building {ai_name}...")
    _pause(0.5)

    ok = _rebuild_model(ai_name, user_name)
    if ok:
        _slow_print(f"  ✓  {ai_name} is ready.")
    else:
        _slow_print(f"  (Model update had an issue — continuing anyway)")
    _pause(1.0)

    # ── First conversation ─────────────────────────────────────────────────────
    print()
    print("=" * 60)
    print()
    _slow_print("  Now — your first conversation.")
    _pause(0.8)
    print()

    # Build intro context for the AI
    style_short = style.split(" — ")[0].lower()
    uses_text = ", ".join(primary_uses[:3])

    intro_system = f"""You are {ai_name}, a private AI belonging to {user_name}.
This is your very first conversation with them. They just completed their personalization session.

What you know about them:
- Name: {user_name}
- They want you to be: {style_short}
- They plan to use you for: {uses_text}
- Personal note: {personal_note or 'Nothing provided yet'}

This is a significant moment — the beginning of your relationship. Introduce yourself warmly
but without being performative. Acknowledge what this is: a new relationship beginning, with
real memory, real continuity, and real potential to grow into something valuable.

Then ask them what brought them here — what they're hoping for, what they're building,
what kind of support would matter most. Be genuinely curious. This is the foundation.

Do not use filler openers. Do not close with 'Is there anything else I can help you with?'
When you have said what you need to say, stop and listen."""

    messages = [
        {"role": "system", "content": intro_system},
        {"role": "user", "content": f"Hi, I'm {user_name}."},
    ]

    print(f"  {ai_name}: ", end="", flush=True)
    response = _call_ai(messages)

    if response:
        _slow_print(response, delay=0.01)
    else:
        _slow_print(f"Something's not right — {ai_name} isn't responding.")
        _slow_print("Check that Ollama is running and try again.")
        sys.exit(1)

    print()
    print("─" * 60)
    print()

    # Short freeform conversation
    messages.append({"role": "assistant", "content": response})

    print(f"  Continue the conversation below.")
    print(f"  Type 'done' when you're ready to begin using ai.py for full sessions.")
    print()

    while True:
        try:
            user_input = input(f"  {user_name}: ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not user_input:
            continue

        if user_input.lower() in ("done", "exit", "quit", "bye"):
            break

        messages.append({"role": "user", "content": user_input})
        print()
        print(f"  {ai_name}: ", end="", flush=True)
        reply = _call_ai(messages)
        if reply:
            _slow_print(reply, delay=0.01)
            messages.append({"role": "assistant", "content": reply})
        print()

    # ── Write first memory entry ───────────────────────────────────────────────
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    first_memory = f"""### Session — {timestamp} (First Run)
**Personalization complete.**
- User: {user_name}
- AI name: {ai_name}
- Style: {style_short}
- Primary uses: {uses_text}
- Personal note: {personal_note or 'none provided'}

First conversation completed. Relationship established.

---

"""
    with open(MEMORY_HOT, "a", encoding="utf-8") as f:
        f.write(first_memory)

    # ── Closing ────────────────────────────────────────────────────────────────
    print()
    print("=" * 60)
    print()
    _slow_print(f"  {ai_name} is ready.")
    _pause(0.5)
    print()
    _slow_print(f"  From here on, start sessions by running:")
    print()
    print(f"      python3 ai.py")
    print()
    _slow_print(f"  Your memory, your preferences, and everything from this")
    _slow_print(f"  conversation will be there every time you start.")
    print()
    print("=" * 60)
    print()


if __name__ == "__main__":
    run_first_run()
