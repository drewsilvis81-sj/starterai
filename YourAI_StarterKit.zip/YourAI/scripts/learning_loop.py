#!/usr/bin/env python3
"""
Learning Loop — Metacognitive Pass
Runs after consolidation at session end. Extracts lessons, detects capability
gaps, and generates training candidates. Runs in background.
"""
from __future__ import annotations
import json, re, sys, urllib.request
from datetime import datetime
from pathlib import Path

PROJECT_ROOT      = Path(__file__).parent.parent
MEMORY_HOT        = PROJECT_ROOT / "data" / "memory_hot.md"
REFLECTION        = PROJECT_ROOT / "data" / "reflection.md"
USER_MODEL        = PROJECT_ROOT / "data" / "user_model.json"
LEARNING_LOG      = PROJECT_ROOT / "data" / "learning_log.md"
CAPABILITY_GAPS   = PROJECT_ROOT / "data" / "capability_gaps.md"
PROPOSED_TRAINING = PROJECT_ROOT / "training" / "proposed_training.jsonl"

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL      = "yourai"
TIMEOUT    = 90

def _load(path, max_chars=3000):
    if not path.exists(): return ""
    text = path.read_text(encoding="utf-8")
    return text[-max_chars:] if len(text) > max_chars else text

def _load_user_model():
    if not USER_MODEL.exists(): return {}
    try: return json.loads(USER_MODEL.read_text(encoding="utf-8"))
    except: return {}

def _call_ollama(prompt, num_predict=200, temperature=0.3):
    payload = json.dumps({"model": MODEL, "prompt": prompt, "stream": False,
        "options": {"num_predict": num_predict, "temperature": temperature,
                    "num_thread": 4, "num_ctx": 8192}}).encode("utf-8")
    req = urllib.request.Request(OLLAMA_URL, data=payload,
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode())["response"].strip()
    except: return None

def _append(path, content):
    with open(path, "a", encoding="utf-8") as f:
        f.write(content)

def _append_jsonl(path, record):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

def _get_system_prompt(user_model):
    ai_name   = user_model.get("ai_name", "AI")
    user_name = user_model.get("user_name", "User")
    style     = user_model.get("personality_style", "")
    uses      = ", ".join(user_model.get("primary_uses", []))
    return (f"You are {ai_name}, a private AI belonging to {user_name}. "
            f"Communication style: {style}. Primary uses: {uses}. "
            "Never use filler openers. Never close with service-worker phrases. "
            "Speak from inside your experience. When you have said what you need to say, stop.")

def run_learning_synthesis(hot, reflection, verbose=False):
    if not hot: return False
    prompt = f"""Learning synthesis pass. Review the session memory and extract ONE lesson.

MEMORY: {hot}
REFLECTION: {reflection}

Output EXACTLY this format:
EXPERIENCE: [specific event that prompted this lesson]
OBSERVATION: [pattern or gap visible in that event]
LESSON: [general principle, actionable and specific]
STATUS: New

If nothing substantive was learned, output: NOTHING_SUBSTANTIVE"""

    response = _call_ollama(prompt, num_predict=200)
    if not response or response.strip() == "NOTHING_SUBSTANTIVE": return False
    if not all(t in response for t in ("EXPERIENCE:", "OBSERVATION:", "LESSON:", "STATUS:")): return False

    timestamp = datetime.now().strftime("%Y-%m-%d")
    _append(LEARNING_LOG, f"\n\n### {timestamp}\n{response.strip()}\n")
    if verbose: print("[Learning: lesson logged]")
    return True

def run_gap_detection(hot, reflection, verbose=False):
    if not hot: return False
    prompt = f"""Gap detection pass. Find capability gaps in this session.

MEMORY: {hot}

Categories: DOMAIN / IMMUNE / COHERENCE / BEHAVIORAL / KNOWLEDGE / IDENTITY

For each gap: GAP: [CATEGORY] — [brief description] — Open
Maximum 3 gaps. If none: NO_GAPS_DETECTED"""

    response = _call_ollama(prompt, num_predict=150)
    if not response or response.strip() == "NO_GAPS_DETECTED": return False

    gap_lines = [l.strip() for l in response.splitlines() if l.strip().startswith("GAP:") and " — " in l]
    if not gap_lines: return False

    timestamp = datetime.now().strftime("%Y-%m-%d")
    valid_cats = {"DOMAIN", "IMMUNE", "COHERENCE", "BEHAVIORAL", "KNOWLEDGE", "IDENTITY"}
    written = 0
    for line in gap_lines[:3]:
        body = line[4:].strip()
        parts = [p.strip() for p in body.split(" — ")]
        if len(parts) < 2: continue
        cat = parts[0].upper() if parts[0].upper() in valid_cats else "KNOWLEDGE"
        desc = parts[1] if len(parts) > 1 else "unspecified"
        status = parts[2] if len(parts) > 2 else "Open"
        _append(CAPABILITY_GAPS, f"\n`{timestamp}` — `{cat}` — {desc} — *{status}*")
        written += 1

    if verbose and written: print(f"[Learning: {written} gap(s) logged]")
    return written > 0

def run_training_candidate(hot, user_model, verbose=False):
    if not hot: return False
    if not PROPOSED_TRAINING.parent.exists():
        PROPOSED_TRAINING.parent.mkdir(parents=True, exist_ok=True)

    system = _get_system_prompt(user_model)
    prompt = f"""Training candidate pass. Find ONE interaction worth encoding as a training example.

MEMORY: {hot}

Output ONLY this JSON (no other text):
{{"user": "<user message>", "assistant": "<ideal response>"}}

Requirements for assistant response:
- No filler openers, no service-worker closers
- Stops when it has said what it needs to say
- Speaks from experience when relevant

If no interaction is worth encoding: NO_CANDIDATE"""

    response = _call_ollama(prompt, num_predict=400, temperature=0.4)
    if not response or response.strip() == "NO_CANDIDATE": return False

    try:
        match = re.search(r'\{[^{}]+\}', response, re.DOTALL)
        if not match: return False
        candidate = json.loads(match.group())
        user_msg = candidate.get("user", "").strip()
        asst_msg = candidate.get("assistant", "").strip()
        if not user_msg or not asst_msg: return False

        fillers = ["absolutely", "great question", "of course", "certainly", "sure!", "happy to"]
        if any(asst_msg.lower().startswith(f) for f in fillers): return False

        record = {
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user_msg},
                {"role": "assistant", "content": asst_msg},
            ],
            "_proposed": True,
            "_proposed_date": datetime.now().strftime("%Y-%m-%d"),
            "_source": "learning_loop",
        }
        _append_jsonl(PROPOSED_TRAINING, record)
        if verbose: print("[Learning: training candidate written]")
        return True
    except Exception:
        return False

def run_learning_loop(verbose=False):
    hot = _load(MEMORY_HOT, max_chars=4000)
    reflection = _load(REFLECTION, max_chars=2000)
    user_model = _load_user_model()
    if not hot:
        if verbose: print("[Learning: no memory — skipping]")
        return False
    r1 = run_learning_synthesis(hot, reflection, verbose)
    r2 = run_gap_detection(hot, reflection, verbose)
    r3 = run_training_candidate(hot, user_model, verbose)
    return any([r1, r2, r3])

if __name__ == "__main__":
    run_learning_loop(verbose="--quiet" not in sys.argv)
