#!/usr/bin/env python3
"""
Roundtable — External AI Consultation
When your AI needs help, it can consult Gemini, Groq, and Claude simultaneously.
API keys go in .env at the project root. See .env.example.
"""
from __future__ import annotations
import json, sys, threading, time, urllib.request
from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).parent.parent
ENV_FILE     = PROJECT_ROOT / ".env"
OLLAMA_URL   = "http://localhost:11434/api/generate"
MODEL        = "yourai"

DEFAULT_GEMINI_MODEL    = "gemini-2.0-flash"
DEFAULT_GROQ_MODEL      = "llama-3.3-70b-versatile"
DEFAULT_ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"
SEAT_TIMEOUT = 20

def _load_env():
    env = {}
    if not ENV_FILE.exists(): return env
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        k, _, v = line.partition("=")
        env[k.strip()] = v.strip()
    return env

def _call_gemini(question, api_key, model):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    payload = json.dumps({"contents": [{"role": "user", "parts": [{"text": question}]}]}).encode()
    req = urllib.request.Request(url, data=payload,
        headers={"Content-Type": "application/json", "x-goog-api-key": api_key}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=SEAT_TIMEOUT) as resp:
            return json.loads(resp.read())["candidates"][0]["content"]["parts"][0]["text"].strip()
    except: return None

def _call_groq(question, api_key, model):
    payload = json.dumps({"model": model, "messages": [{"role": "user", "content": question}],
        "max_completion_tokens": 400}).encode()
    req = urllib.request.Request("https://api.groq.com/openai/v1/chat/completions",
        data=payload, headers={"Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=SEAT_TIMEOUT) as resp:
            return json.loads(resp.read())["choices"][0]["message"]["content"].strip()
    except: return None

def _call_anthropic(question, api_key, model):
    payload = json.dumps({"model": model, "max_tokens": 400,
        "messages": [{"role": "user", "content": question}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages",
        data=payload, headers={"Content-Type": "application/json",
        "x-api-key": api_key, "anthropic-version": "2023-06-01"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=SEAT_TIMEOUT) as resp:
            return json.loads(resp.read())["content"][0]["text"].strip()
    except: return None

def _call_ollama_local(prompt):
    payload = json.dumps({"model": MODEL, "prompt": prompt, "stream": False,
        "options": {"num_predict": 250, "temperature": 0.3, "num_thread": 4, "num_ctx": 8192}
    }).encode()
    req = urllib.request.Request(OLLAMA_URL, data=payload,
        headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read()).get("response", "").strip()
    except: return None

def _query_seat(name, fn, question, api_key, model, results):
    start = time.time()
    try:
        results[name] = {"text": fn(question, api_key, model), "elapsed": round(time.time()-start, 1)}
    except:
        results[name] = {"text": None, "elapsed": None}

def _synthesize(question, seat_responses):
    seat_block = "".join(f"\n\n{name.upper()}:\n{text}" for name, text in seat_responses.items())
    prompt = f"""Synthesize these AI consultant responses for a private AI to use.

QUESTION: {question}
RESPONSES:{seat_block}

CONSENSUS: [what all agree on, 1-2 sentences]
DIVERGENCE: [meaningful disagreement, or "None"]
KEY CONTEXT: [2-3 most important facts or caveats]

Under 150 words. Dense. No filler."""
    return _call_ollama_local(prompt) or "Synthesis unavailable."

def run_roundtable(question, verbose=True):
    env = _load_env()
    seats = []

    g_key = env.get("GEMINI_API_KEY", "")
    if g_key and not g_key.startswith("your_"):
        seats.append(("Gemini", _call_gemini, g_key, env.get("ROUNDTABLE_GEMINI_MODEL", DEFAULT_GEMINI_MODEL)))

    gr_key = env.get("GROQ_API_KEY", "")
    if gr_key and not gr_key.startswith("your_"):
        seats.append(("Groq", _call_groq, gr_key, env.get("ROUNDTABLE_GROQ_MODEL", DEFAULT_GROQ_MODEL)))

    a_key = env.get("ANTHROPIC_API_KEY", "")
    if a_key and not a_key.startswith("your_"):
        seats.append(("Claude", _call_anthropic, a_key, env.get("ROUNDTABLE_ANTHROPIC_MODEL", DEFAULT_ANTHROPIC_MODEL)))

    if not seats:
        return ("[ROUNDTABLE: no API keys configured]\n"
                "Add keys to .env — see .env.example for setup instructions.")

    if verbose:
        print(f"  [Roundtable: consulting {', '.join(s[0] for s in seats)}...]")

    results = {}
    threads = [threading.Thread(target=_query_seat, args=(n, fn, question, k, m, results), daemon=True)
               for n, fn, k, m in seats]
    for t in threads: t.start()
    for t in threads: t.join(timeout=SEAT_TIMEOUT + 5)

    successful = {n: r["text"] for n, _, _, _ in seats
                  if (r := results.get(n, {})) and r.get("text")}
    failed = [n for n, _, _, _ in seats if n not in successful]

    if verbose:
        for n in successful: print(f"  ✓ {n} ({results[n].get('elapsed','?')}s)")
        for n in failed: print(f"  ✗ {n} (no response)")

    if not successful:
        return "[ROUNDTABLE: all seats failed — check keys and connectivity]"

    if verbose: print(f"  [Synthesizing {len(successful)} response(s)...]")
    synthesis = _synthesize(question, successful)

    topic_short = question[:60] + "..." if len(question) > 60 else question
    header = f"[ROUNDTABLE — {len(successful)} seat(s): {', '.join(successful.keys())}]"
    if failed: header += f" [{', '.join(failed)} unavailable]"
    return f"{header}\nTopic: {topic_short}\n\n{synthesis}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 scripts/roundtable.py \"your question\"")
        sys.exit(1)
    q = " ".join(sys.argv[1:])
    print(f"\nQuestion: {q}\n")
    print(run_roundtable(q, verbose=True))
