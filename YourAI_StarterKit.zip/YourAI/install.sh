#!/bin/bash
# ──────────────────────────────────────────────────────────────
#  Your AI — Installer
#  Run this once before your first session.
#  Usage: bash install.sh
# ──────────────────────────────────────────────────────────────

set -e

BOLD="\033[1m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
RED="\033[0;31m"
RESET="\033[0m"

echo ""
echo "──────────────────────────────────────────────────────────────"
echo "  Your AI — Setup"
echo "──────────────────────────────────────────────────────────────"
echo ""

# ── Step 1: Check Python 3 ─────────────────────────────────────
echo -n "  Checking Python 3... "
if command -v python3 &>/dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1)
    echo -e "${GREEN}✓  $PYTHON_VERSION${RESET}"
else
    echo -e "${RED}✗  Not found${RESET}"
    echo ""
    echo "  Python 3 is required. Install it from: https://python.org/downloads"
    echo "  Then run this script again."
    exit 1
fi

# ── Step 2: Check Ollama ───────────────────────────────────────
echo -n "  Checking Ollama... "
if command -v ollama &>/dev/null; then
    OLLAMA_VERSION=$(ollama --version 2>&1 | head -1)
    echo -e "${GREEN}✓  $OLLAMA_VERSION${RESET}"
else
    echo -e "${RED}✗  Not found${RESET}"
    echo ""
    echo "  Ollama is required. Install it from: https://ollama.com"
    echo "  After installing, run: ollama serve"
    echo "  Then run this script again."
    exit 1
fi

# ── Step 3: Check Ollama is running ───────────────────────────
echo -n "  Checking Ollama is running... "
if curl -s http://localhost:11434/api/tags &>/dev/null; then
    echo -e "${GREEN}✓  Running${RESET}"
else
    echo -e "${YELLOW}⚠  Not running${RESET}"
    echo ""
    echo "  Starting Ollama in the background..."
    ollama serve &>/dev/null &
    sleep 3
    if curl -s http://localhost:11434/api/tags &>/dev/null; then
        echo -e "  ${GREEN}✓  Ollama started${RESET}"
    else
        echo ""
        echo "  Could not start Ollama automatically."
        echo "  Open a new terminal, run: ollama serve"
        echo "  Then come back and run this script again."
        exit 1
    fi
fi

# ── Step 4: Pull base model ────────────────────────────────────
echo ""
echo "  Downloading the AI base model (qwen2.5:3b)..."
echo "  This is about 2GB. It only happens once."
echo ""
ollama pull qwen2.5:3b

# ── Step 5: Create the model ──────────────────────────────────
echo ""
echo -n "  Building your AI model... "
ollama create yourai -f Modelfile
echo -e "${GREEN}✓  Done${RESET}"

# ── Step 6: Create training directory ─────────────────────────
mkdir -p training
touch training/proposed_training.jsonl

# ── Done ───────────────────────────────────────────────────────
echo ""
echo "──────────────────────────────────────────────────────────────"
echo -e "  ${GREEN}${BOLD}Setup complete.${RESET}"
echo ""
echo "  To start your first session:"
echo ""
echo -e "      ${BOLD}python3 first_run.py${RESET}"
echo ""
echo "  This will introduce you to your AI and personalize it for you."
echo "  After that, start future sessions with:"
echo ""
echo -e "      ${BOLD}python3 ai.py${RESET}"
echo ""
echo "  Optional: to add roundtable consultation (Gemini, Groq, Claude),"
echo "  copy .env.example to .env and add your API keys."
echo ""
echo "──────────────────────────────────────────────────────────────"
echo ""
