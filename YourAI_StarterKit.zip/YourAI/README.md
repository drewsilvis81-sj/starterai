# Your AI — Setup Guide

Welcome. This is a private AI that belongs only to you.
Follow these steps to get started.

---

## Requirements

- **A Mac or Linux computer** (Windows support coming later)
- **Python 3** — check with: `python3 --version`
  - If not installed: https://python.org/downloads
- **Ollama** — the software that runs the AI locally on your machine
  - Install from: https://ollama.com
  - After installing, open a terminal and run: `ollama serve`

---

## First-Time Setup (do this once)

**1. Open Terminal**
On Mac: press `Command + Space`, type "Terminal", press Enter.

**2. Navigate to this folder**
```
cd ~/Downloads/YourAI
```
(Replace `~/Downloads/YourAI` with wherever you unzipped this folder.)

**3. Run the installer**
```
bash install.sh
```
This downloads the AI model (~2GB, one time only) and sets everything up.

**4. Start your personalization session**
```
python3 first_run.py
```
This introduces you to your AI and lets you name it, set its style, and
tell it who you are. Takes about 5 minutes.

---

## Starting a Session

After first run, always start with:
```
python3 ai.py
```

---

## Commands During a Session

| Command | What it does |
|---------|-------------|
| `/roundtable` | Consult Gemini, Groq & Claude on your last question |
| `/consult [topic]` | Consult on a specific topic |
| `/memory` | Show how many sessions are in memory |
| `/help` | Show all commands |
| `/bye` | End session (you'll be asked to save) |

---

## Optional: Roundtable Consultation

Your AI can consult external AIs (Gemini, Groq, Claude) when it needs
more perspectives. This requires free API keys.

1. Copy `.env.example` to `.env`
2. Add your keys (links in the file)
3. Use `/roundtable` during sessions

---

## Your Files

| File | Purpose |
|------|---------|
| `ai.py` | Start sessions here |
| `first_run.py` | First-time setup (run once) |
| `data/user_model.json` | Your preferences and profile |
| `data/core.md` | Add context you always want your AI to know |
| `data/memory_hot.md` | Recent session memory |
| `data/learning_log.md` | Lessons your AI extracts from sessions |
| `data/capability_gaps.md` | Where your AI fell short (training priorities) |

---

## Questions?

Read `docs/USER_GUIDE.md` for day-to-day usage.
Read `docs/AI_OVERVIEW.md` to understand what your AI actually is.
